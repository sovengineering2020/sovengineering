SOV Engineering JSON backup
Created: 2026-10-27T08:23:43.230Z
Repository: lovelymari121201-bit/sovengineering
Backup folder: backup/
Archive includes the data/csv/ directory tree and manifest.json.
Original monthly CSV files are not modified by this backup operation.
